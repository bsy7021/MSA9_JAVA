package Day08.Ex01_AnonymousObject;

public class Person {
	
	String name;
	int age;
	
	void work() {
		System.out.println("일을 합니다.");
	}
	
}
