package Day01;

// 주석 : ctrl + /	or	ctrl + shift + C
// 한 줄 복사 : ctrl + alt + ↑/↓
// 한 줄 삭제 : ctrl + D
// 코드 이동 : alt + ↑/↓
// 스크롤 이동 : ctrl + ↑/↓
// 새 파일 생성 : ctrl + N
// 탭 종료 : ctrl + W
// 전체 탭 종료 : ctrl + shift + W
// 프로그램 실행 : ctrl + F11
// 이름바꾸기 : F2
// 찾기바꾸기 : ctrl + F
// 단어 찾기 : ctrl + K
// 파일 찾기 : ctrl + shift + R
// 코드 찾기 : ctrl + H
// 퀵 서치 : ctrl + alt + shift + L
// 잘라내기 : ctrl + X
// 뒤로가기 : ctrl + Z
// 앞으로가기 : ctrl + Y
// 전체화면 : ctrl + M

public class 단축키 {
	
}
