package Day01;

import java.util.Scanner;

// * 자동완성 템플릿 세팅하기
// 1.[Window]
// 2.[Preferences] (설정)
// 3.[Java] > [Editor] > [Template]
// 4. 자동완성 키워드 및 코드 작성
public class 자동완성 {
	public static void main(String[] args) {
		// sysp : ctrl + space
		System.out.print("홀리갓");
		// scnew : ctrl + space
		Scanner sc = new Scanner(System.in);
	}
}
