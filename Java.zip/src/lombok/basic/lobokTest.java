package lombok.basic;

public class lobokTest {
	public static void main(String[] args) {
		Person person = new Person();
		System.out.println(person);
	}
}
