package Day09.Ex07_Review.추상클래스;

public class Macbook extends Laptop {

	@Override
	public void typing() {
		System.out.println("MacBook - typing");
	}

}
