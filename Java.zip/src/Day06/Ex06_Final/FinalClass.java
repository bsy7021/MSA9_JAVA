package Day06.Ex06_Final;

public final class FinalClass {
	public void method() {
		System.out.println("메소드 출력!");
	}
}
//final로 지정한 클래스는 상속을 할 수 없다.
/*
class SubClass extends FinalClass{
	
}
*/