/**
 * 
 */
/**
 * 
 */
module Java {
	//requires 필요한 모듈을 설정
	//- static 컴파일 시점에서 모듈을 포함
	requires static lombok;
}